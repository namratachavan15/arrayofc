//Accept 10 numbers in array & display sum of 10 numbers
#include<stdio.h>
int main()
{
   int i,a[10],s=0;
  
   printf("\nEnter array elements\n");
   for(i=0;i<10;i++)
   {
      scanf("%d",&a[i]);
   }
   printf("\narray elements are:\n");
   for(i=0;i<10;i++)
   {
     printf("\n%d",a[i]);
	 s=s+a[i];
   }
   printf("\nsum of 10 numbers=%d",s);
}
