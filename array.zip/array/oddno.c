//C program to print odd  numbers in an array 
#include <stdio.h>
int main() 
{
    int n,i;
    printf("Enter number of elements in the array: ");
    scanf("%d", &n);
    int arr[n];  
    printf("Enter %d elements in the array: ",n);
    for( i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("\nOdd numbers in the array are: ");
    for(i=0;i<n;i++)
    {
        if(arr[i]%2==1)
            printf("%d ", arr[i]);
    }   
}
