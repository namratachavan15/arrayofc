//substraction of matrix
#include<stdio.h>
int main()
{
	int a[3][3],b[3][3],sub[3][3],i,j;	
	printf("enter matrix:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("\n enter second matrix");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&b[i][j]);
		}
	}
	printf("first matix:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%5d",a[i][j]);
		}
		printf("\n");
	}
	printf("second matrix:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%5d",b[i][j]);
		}
		printf("\n");
	}
	printf("substraction of matrix:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			sub[i][j]=a[i][j]+b[i][j];
			printf("%5d",sub[i][j]);
		}
		printf("\n");
	}
}
