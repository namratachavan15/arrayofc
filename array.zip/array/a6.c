//sort array elements in descending order
#include<stdio.h>
int main()
{
   int i,a[10],j,no1; 
   printf("\nEnter array elements\n");
   for(i=0;i<10;i++)
   {
      scanf("%d",&a[i]);
   }
   printf("\narray elements are:\n");
   for(i=0;i<10;i++)
   {
     printf("\n%d",a[i]);
   }
 for(i=0;i<10;i++)
 {
   for(j=i+1;j<10;j++)
   {
       if(a[i]<a[j])
       {
	   		no1=a[i];
	   		a[i]=a[j];
	   		a[j]=no1;
       }
   }
 }
   printf("\narray elements in descending order\n");
   for(i=0;i<10;i++)
   {
 	  	printf("\n%d",a[i]);
   }
 }
