//Accept 10 numbers in array & display it
#include<stdio.h>

int main()
{
   int i,a[10];
  
   printf("\nEnter array elements\n");
   for(i=0;i<=10;i++)
   {
      scanf("%d",&a[i]);
   }
   printf("\narray elements are:\n");
   for(i=0;i<=10;i++)
   {
     printf("\n%d",a[i]);

   }
}
