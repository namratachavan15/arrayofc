//Accept 10 numbers in array & print reverse of it
#include<stdio.h>
int main()
{
   int i,a[10],no1;
   printf("\nEnter array elements\n");
   for(i=0;i<10;i++)
   {
      scanf("%d",&a[i]);
   }
   printf("\nReversed array elements are:\n");
   for(i=9;i>=0;i--)
   {
     printf("\n%d",a[i]);
   }
 }
