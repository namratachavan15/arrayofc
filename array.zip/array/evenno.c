//C program to print even  numbers in an array 
#include <stdio.h>
int main() 
{
    int n,i;
    int arr[n];  
    printf("Enter number of elements in the array: ");
    scanf("%d", &n);
    printf("Enter %d elements in the array: ",n);
    for( i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Even numbers in the array are: ");
    for(i=0;i<n;i++)
    {
        if(arr[i]%2==0)
            printf("%d ", arr[i]);
    }  
}
