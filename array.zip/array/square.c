//C program to print the square of array elements
#include <stdio.h>
int main()
{
    int arr[5] = { 1, 2, 3, 4, 5 };
    int i = 0;
    printf("Array elements: \n");
    for (i = 0; i < 5; i++)
        printf("%d ", arr[i]);
    printf("\nSquare of array elements: \n");
    for (i = 0; i < 5; i++)
        printf("%d ", arr[i] * arr[i]);
    printf("\n");
    return 0;
}
